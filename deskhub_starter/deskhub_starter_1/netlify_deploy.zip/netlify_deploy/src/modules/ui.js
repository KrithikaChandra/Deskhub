let toastRegion = null;

function ensureToastRegion() {
  if (toastRegion) return toastRegion;

  toastRegion = document.createElement("div");
  toastRegion.className = "toast-region";
  toastRegion.setAttribute("aria-live", "polite");
  toastRegion.setAttribute("aria-atomic", "true");
  document.body.appendChild(toastRegion);
  return toastRegion;
}

export function toast(message, type = "success") {
  const region = ensureToastRegion();
  const item = document.createElement("div");
  item.className = `toast toast--${type}`;
  item.textContent = message;
  region.appendChild(item);

  window.setTimeout(() => {
    item.classList.add("is-leaving");
    window.setTimeout(() => item.remove(), 180);
  }, 3000);
}

export function openModal({ title, content, actions }) {
  const previousFocus = document.activeElement;
  const overlay = document.createElement("div");
  overlay.className = "modal-overlay";

  const dialog = document.createElement("section");
  dialog.className = "modal";
  dialog.setAttribute("role", "dialog");
  dialog.setAttribute("aria-modal", "true");

  const headingId = `modal-title-${Date.now()}`;
  dialog.setAttribute("aria-labelledby", headingId);

  const header = document.createElement("div");
  header.className = "modal__header";

  const heading = document.createElement("h2");
  heading.id = headingId;
  heading.textContent = title;

  const closeBtn = document.createElement("button");
  closeBtn.type = "button";
  closeBtn.className = "modal__close";
  closeBtn.setAttribute("aria-label", "Close");
  closeBtn.textContent = "x";

  header.append(heading, closeBtn);

  const body = document.createElement("div");
  body.className = "modal__body";
  body.append(content);

  dialog.append(header, body);

  if (actions) {
    const footer = document.createElement("div");
    footer.className = "modal__footer";
    footer.append(actions);
    dialog.append(footer);
  }

  overlay.append(dialog);
  document.body.append(overlay);
  document.body.classList.add("has-modal");

  function close() {
    document.removeEventListener("keydown", onKeydown);
    overlay.remove();
    document.body.classList.remove("has-modal");
    if (previousFocus instanceof HTMLElement) previousFocus.focus();
  }

  function onKeydown(event) {
    if (event.key === "Escape") close();
  }

  closeBtn.addEventListener("click", close);
  overlay.addEventListener("click", (event) => {
    if (event.target === overlay) close();
  });
  document.addEventListener("keydown", onKeydown);

  const firstField = dialog.querySelector("input, select, textarea, button");
  if (firstField instanceof HTMLElement) firstField.focus();

  return { close, element: overlay };
}

export function confirmDialog(message, title = "Are you sure?") {
  return new Promise((resolve) => {
    const content = document.createElement("p");
    content.className = "modal__message";
    content.textContent = message;

    const actions = document.createElement("div");
    actions.className = "modal-actions";

    const cancelBtn = document.createElement("button");
    cancelBtn.type = "button";
    cancelBtn.className = "button button--secondary";
    cancelBtn.textContent = "Cancel";

    const confirmBtn = document.createElement("button");
    confirmBtn.type = "button";
    confirmBtn.className = "button button--danger";
    confirmBtn.textContent = "Yes, delete";

    actions.append(cancelBtn, confirmBtn);

    const modal = openModal({ title, content, actions });
    cancelBtn.addEventListener("click", () => {
      modal.close();
      resolve(false);
    });
    confirmBtn.addEventListener("click", () => {
      modal.close();
      resolve(true);
    });
  });
}
