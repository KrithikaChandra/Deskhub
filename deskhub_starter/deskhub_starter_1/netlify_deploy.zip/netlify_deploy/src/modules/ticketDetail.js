import * as ticketsApi from "../api/tickets.js";
import * as usersApi from "../api/users.js";
import { formatDate } from "../utils/formatDate.js";
import { confirmDialog, toast } from "./ui.js";

const STATUS_OPTIONS = ["open", "in-progress", "resolved", "closed"];
const PRIORITY_OPTIONS = ["low", "medium", "high", "urgent"];

let ticketId = null;
let currentTicket = null;
let currentComments = [];
let users = [];

function byId(id) {
  return document.querySelector(`#${id}`);
}

function userName(id) {
  if (id == null) return "Unassigned";
  const user = users.find((item) => String(item.id) === String(id));
  return user ? String(user.name ?? `User #${id}`) : `User #${id}`;
}

function setLoading(isLoading) {
  const loadingEl = byId("ticket-detail-loading");
  const contentEl = byId("ticket-detail-content");
  if (loadingEl) loadingEl.hidden = !isLoading;
  if (contentEl) contentEl.hidden = isLoading;
}

function showError(message) {
  const errorEl = byId("ticket-detail-error");
  const loadingEl = byId("ticket-detail-loading");
  const contentEl = byId("ticket-detail-content");
  if (loadingEl) loadingEl.hidden = true;
  if (contentEl) contentEl.hidden = true;
  if (errorEl) {
    errorEl.hidden = false;
    errorEl.textContent = message;
  }
}

function populateAssignees() {
  const select = byId("detail-assignee");
  if (!(select instanceof HTMLSelectElement)) return;

  select.replaceChildren();

  const unassigned = document.createElement("option");
  unassigned.value = "";
  unassigned.textContent = "Unassigned";
  select.appendChild(unassigned);

  for (const user of users) {
    const option = document.createElement("option");
    option.value = String(user.id);
    option.textContent = String(user.name ?? `User #${user.id}`);
    select.appendChild(option);
  }
}

function renderComments(comments) {
  const wrap = byId("ticket-comments");
  if (!wrap) return;

  if (!comments.length) {
    const empty = document.createElement("p");
    empty.className = "comments-empty";
    empty.textContent = "No comments yet.";
    wrap.replaceChildren(empty);
    return;
  }

  const frag = document.createDocumentFragment();
  for (const comment of comments) {
    const article = document.createElement("article");
    article.className = "comment-item";

    const meta = document.createElement("p");
    meta.className = "comment-item__meta";
    const author = userName(comment.authorId);
    const created = comment.createdAt ? formatDate(comment.createdAt) : "-";
    meta.textContent = `${author} - ${created}`;

    const body = document.createElement("p");
    body.textContent = String(comment.content ?? "");

    article.append(meta, body);
    frag.append(article);
  }

  wrap.replaceChildren(frag);
}

function renderTicket(ticket, comments) {
  currentTicket = ticket;
  currentComments = comments;

  byId("ticket-detail-id").textContent =
    ticket.id != null ? `Ticket #${ticket.id}` : "Ticket";
  byId("ticket-detail-title").textContent = String(ticket.title ?? "");
  byId("ticket-customer").textContent = String(ticket.customerName ?? "-");
  byId("ticket-email").textContent = String(ticket.customerEmail ?? "-");
  byId("ticket-category").textContent = String(ticket.category ?? "-");
  byId("ticket-created").textContent = ticket.createdAt
    ? formatDate(ticket.createdAt)
    : "-";
  byId("ticket-updated").textContent = ticket.updatedAt
    ? formatDate(ticket.updatedAt)
    : "-";
  byId("ticket-description").textContent = String(ticket.description ?? "");

  const status = byId("detail-status");
  const priority = byId("detail-priority");
  const assignee = byId("detail-assignee");
  if (status instanceof HTMLSelectElement) status.value = String(ticket.status ?? "open");
  if (priority instanceof HTMLSelectElement) priority.value = String(ticket.priority ?? "medium");
  if (assignee instanceof HTMLSelectElement) {
    assignee.value = ticket.assignedTo == null ? "" : String(ticket.assignedTo);
  }

  renderComments(comments);
}

async function updateTicketField(field, value) {
  if (!ticketId || !currentTicket) return;

  const previousValue = currentTicket[field];
  currentTicket[field] = value;

  try {
    const updated = await ticketsApi.updateTicket(ticketId, {
      [field]: value,
      updatedAt: new Date().toISOString(),
    });
    currentTicket = {
      ...currentTicket,
      ...(updated && typeof updated === "object" ? updated : {}),
    };
    toast("Ticket updated.");
  } catch (err) {
    currentTicket[field] = previousValue;
    renderTicket(currentTicket, currentComments);
    toast(err instanceof Error ? err.message : "Could not update ticket.", "error");
  }
}

function wireActions() {
  const status = byId("detail-status");
  const priority = byId("detail-priority");
  const assignee = byId("detail-assignee");
  const deleteBtn = byId("ticket-delete");

  if (status instanceof HTMLSelectElement) {
    status.addEventListener("change", () => {
      if (STATUS_OPTIONS.includes(status.value)) {
        void updateTicketField("status", status.value);
      }
    });
  }

  if (priority instanceof HTMLSelectElement) {
    priority.addEventListener("change", () => {
      if (PRIORITY_OPTIONS.includes(priority.value)) {
        void updateTicketField("priority", priority.value);
      }
    });
  }

  if (assignee instanceof HTMLSelectElement) {
    assignee.addEventListener("change", () => {
      const value = assignee.value === "" ? null : Number(assignee.value);
      void updateTicketField("assignedTo", value);
    });
  }

  if (deleteBtn instanceof HTMLButtonElement) {
    deleteBtn.addEventListener("click", async () => {
      const confirmed = await confirmDialog(
        "This ticket and its comments will be removed from the list."
      );
      if (!confirmed || !ticketId) return;

      try {
        await ticketsApi.deleteTicket(ticketId);
        toast("Ticket deleted.");
        window.location.href = new URL("./tickets.html", window.location.href).href;
      } catch (err) {
        toast(err instanceof Error ? err.message : "Could not delete ticket.", "error");
      }
    });
  }
}

export async function initTicketDetail() {
  const id = new URLSearchParams(window.location.search).get("id");
  if (!id) {
    showError("Missing ticket id.");
    return;
  }

  ticketId = id;
  setLoading(true);
  wireActions();

  try {
    const [ticket, comments, userList] = await Promise.all([
      ticketsApi.getTicket(id),
      ticketsApi.listComments(id),
      usersApi.listUsers(),
    ]);

    users = Array.isArray(userList) ? userList : [];
    populateAssignees();
    renderTicket(ticket, Array.isArray(comments) ? comments : []);
    setLoading(false);
  } catch (err) {
    showError(err instanceof Error ? err.message : "Could not load ticket.");
  }
}
